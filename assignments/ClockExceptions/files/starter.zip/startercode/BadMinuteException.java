/**
   Exception thrown specifically when an invalid minute is used
   @author krodgers
**/

// TODO - implement the BadMinuteException class
